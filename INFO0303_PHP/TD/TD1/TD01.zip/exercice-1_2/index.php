<?php
header("Location: table1.php");